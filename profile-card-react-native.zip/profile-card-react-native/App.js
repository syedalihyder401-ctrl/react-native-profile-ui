import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.card}>

        {/* Profile Image */}
        <Image
          source={{ uri: 'https://via.placeholder.com/100' }}
          style={styles.profileImg}
        />

        {/* Name & Role */}
        <Text style={styles.name}>Maaz Shoaib</Text>
        <Text style={styles.role}>Software Engineer</Text>

        {/* Buttons */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.followBtn}>
            <Text style={styles.followText}>Follow</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.messageBtn}>
            <Text>Message</Text>
          </TouchableOpacity>
        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f2f5',
    justifyContent: 'center',
    alignItems: 'center',
  },

  card: {
    width: 300,
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    elevation: 5, // Android shadow
  },

  profileImg: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 15,
  },

  name: {
    fontSize: 20,
    fontWeight: 'bold',
  },

  role: {
    color: 'gray',
    marginBottom: 20,
  },

  buttonContainer: {
    flexDirection: 'row',              
    justifyContent: 'space-between',  
    width: '100%',
  },

  followBtn: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 8,
    width: '45%',
    alignItems: 'center',
  },

  followText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  messageBtn: {
    backgroundColor: '#e4e6eb',
    padding: 10,
    borderRadius: 8,
    width: '45%',
    alignItems: 'center',
  },
});